{
  "urlArgs": "version=2j",
  "paths": {
    "bignumber": "modules/lib/bignumber-9.1.2-min",
    "raphael": "modules/lib/raphael-2.3.0-min",
    "PciUtilities": "modules/PciUtilities",
    "PlottedPoint": "modules/PlottedPoint",
    "FullPlane": "modules/FullPlane",
    "CoordinatePlaneFactory": "modules/CoordinatePlaneFactory",
    "Graph": "modules/Graph",
    "GraphingModule": "modules/GraphingModule",
    "GraphingInteraction": "modules/GraphingInteraction"
  }
}
